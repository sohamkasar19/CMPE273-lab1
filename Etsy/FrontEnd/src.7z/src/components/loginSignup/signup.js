import React, { Component } from 'react';

import { Redirect } from 'react-router';


class Signup extends Component {
    render() {
        return (
            <h1>Signup</h1>
        )

        
    }
}
export default Signup;